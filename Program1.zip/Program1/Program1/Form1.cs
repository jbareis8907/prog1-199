﻿//B2640
//CIS199-75
//Program 1
//9-26-17
//This program allows the user to enter the length and height of the walls they want painted along
//with the number of doors, windows, and coats of paint desired.  Based on this input, it calculates
//the total square footage needed and displays the minimum gallons needed as well as the number of gallons
//to buy rounded to the nearest whole number.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        //declare constants
        const int doorArea = 20; //area of door
        const int windowArea = 15; //area of window
        const int canPaint = 350; //can of paint coverage

        

        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //declare variables
            double totalLength; //length of all walls
            double totalHeight; //height of all walls
            int numberDoors; //number of doors in room
            int numberWindows; //number of windows in room
            int numberCoats; //number of coats desired
            double squareFeet; //square feet of room
            double squareFeetPainted; //square feet minus windows and doors
            double totalSquareFeet; //total sqaure foot with number of coats
            double minGallons; //minum gallons needed calculation
            double gallonsToBuy; //number of gallons needed to buy rounded to whole number

            //get user input and assign to variables
            totalLength = double.Parse(lengthTextBox.Text);
            totalHeight = double.Parse(heightTextBox.Text);
            numberDoors = int.Parse(doorsTextBox.Text);
            numberWindows = int.Parse(windowsTextBox.Text);
            numberCoats = int.Parse(coatsTextBox.Text);

            //calcualte square feet
            squareFeet = totalLength * totalHeight;

            //calculate total square feet to be painted per coat
            squareFeetPainted = squareFeet - numberDoors * doorArea - numberWindows * windowArea;

            //calculate total square feet
            totalSquareFeet = squareFeetPainted * numberCoats;

            //Calcualte the minimum gallons to buy
            minGallons = totalSquareFeet / canPaint;

            //calculate the number of gallons to buy, rounded up
            gallonsToBuy = Math.Ceiling(minGallons);

            //display the minimum gallons needed
            minimumOutputLabel.Text = minGallons.ToString("n1");

            //display the gallons of paint needed to buy
            neededOutputLabel.Text = gallonsToBuy.ToString("n0");







        }
    }
}
