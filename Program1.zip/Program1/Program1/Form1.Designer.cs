﻿namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lengthLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.doorsLabel = new System.Windows.Forms.Label();
            this.windowLabel = new System.Windows.Forms.Label();
            this.coatsLabel = new System.Windows.Forms.Label();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.doorsTextBox = new System.Windows.Forms.TextBox();
            this.windowsTextBox = new System.Windows.Forms.TextBox();
            this.coatsTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.minimumGallonsLabel = new System.Windows.Forms.Label();
            this.gallonsNeededLabel = new System.Windows.Forms.Label();
            this.minimumOutputLabel = new System.Windows.Forms.Label();
            this.neededOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(59, 20);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(229, 20);
            this.lengthLabel.TabIndex = 0;
            this.lengthLabel.Text = "Total length of all walls (in feet):";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(59, 68);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(229, 20);
            this.heightLabel.TabIndex = 1;
            this.heightLabel.Text = "Total height of all walls (in feet):";
            // 
            // doorsLabel
            // 
            this.doorsLabel.AutoSize = true;
            this.doorsLabel.Location = new System.Drawing.Point(63, 116);
            this.doorsLabel.Name = "doorsLabel";
            this.doorsLabel.Size = new System.Drawing.Size(225, 20);
            this.doorsLabel.TabIndex = 2;
            this.doorsLabel.Text = "Number of doors (non-neg int):";
            // 
            // windowLabel
            // 
            this.windowLabel.AutoSize = true;
            this.windowLabel.Location = new System.Drawing.Point(43, 164);
            this.windowLabel.Name = "windowLabel";
            this.windowLabel.Size = new System.Drawing.Size(245, 20);
            this.windowLabel.TabIndex = 3;
            this.windowLabel.Text = "Number of windows (non-neg int):";
            // 
            // coatsLabel
            // 
            this.coatsLabel.AutoSize = true;
            this.coatsLabel.Location = new System.Drawing.Point(7, 212);
            this.coatsLabel.Name = "coatsLabel";
            this.coatsLabel.Size = new System.Drawing.Size(281, 20);
            this.coatsLabel.TabIndex = 4;
            this.coatsLabel.Text = "Number of coats of paint (non-neg int):";
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(294, 17);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(100, 26);
            this.lengthTextBox.TabIndex = 5;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(294, 65);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(100, 26);
            this.heightTextBox.TabIndex = 6;
            // 
            // doorsTextBox
            // 
            this.doorsTextBox.Location = new System.Drawing.Point(294, 113);
            this.doorsTextBox.Name = "doorsTextBox";
            this.doorsTextBox.Size = new System.Drawing.Size(100, 26);
            this.doorsTextBox.TabIndex = 7;
            // 
            // windowsTextBox
            // 
            this.windowsTextBox.Location = new System.Drawing.Point(294, 161);
            this.windowsTextBox.Name = "windowsTextBox";
            this.windowsTextBox.Size = new System.Drawing.Size(100, 26);
            this.windowsTextBox.TabIndex = 8;
            // 
            // coatsTextBox
            // 
            this.coatsTextBox.Location = new System.Drawing.Point(294, 209);
            this.coatsTextBox.Name = "coatsTextBox";
            this.coatsTextBox.Size = new System.Drawing.Size(100, 26);
            this.coatsTextBox.TabIndex = 9;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(216, 262);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(122, 30);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // minimumGallonsLabel
            // 
            this.minimumGallonsLabel.AutoSize = true;
            this.minimumGallonsLabel.Location = new System.Drawing.Point(12, 313);
            this.minimumGallonsLabel.Name = "minimumGallonsLabel";
            this.minimumGallonsLabel.Size = new System.Drawing.Size(245, 20);
            this.minimumGallonsLabel.TabIndex = 11;
            this.minimumGallonsLabel.Text = "Minimum gallons of paint needed:";
            // 
            // gallonsNeededLabel
            // 
            this.gallonsNeededLabel.AutoSize = true;
            this.gallonsNeededLabel.Location = new System.Drawing.Point(43, 342);
            this.gallonsNeededLabel.Name = "gallonsNeededLabel";
            this.gallonsNeededLabel.Size = new System.Drawing.Size(211, 20);
            this.gallonsNeededLabel.TabIndex = 12;
            this.gallonsNeededLabel.Text = "Gallons of paint need to buy:";
            // 
            // minimumOutputLabel
            // 
            this.minimumOutputLabel.Location = new System.Drawing.Point(263, 313);
            this.minimumOutputLabel.Name = "minimumOutputLabel";
            this.minimumOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.minimumOutputLabel.TabIndex = 13;
            // 
            // neededOutputLabel
            // 
            this.neededOutputLabel.Location = new System.Drawing.Point(260, 342);
            this.neededOutputLabel.Name = "neededOutputLabel";
            this.neededOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.neededOutputLabel.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 383);
            this.Controls.Add(this.neededOutputLabel);
            this.Controls.Add(this.minimumOutputLabel);
            this.Controls.Add(this.gallonsNeededLabel);
            this.Controls.Add(this.minimumGallonsLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.coatsTextBox);
            this.Controls.Add(this.windowsTextBox);
            this.Controls.Add(this.doorsTextBox);
            this.Controls.Add(this.heightTextBox);
            this.Controls.Add(this.lengthTextBox);
            this.Controls.Add(this.coatsLabel);
            this.Controls.Add(this.windowLabel);
            this.Controls.Add(this.doorsLabel);
            this.Controls.Add(this.heightLabel);
            this.Controls.Add(this.lengthLabel);
            this.Name = "Form1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Label doorsLabel;
        private System.Windows.Forms.Label windowLabel;
        private System.Windows.Forms.Label coatsLabel;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox doorsTextBox;
        private System.Windows.Forms.TextBox windowsTextBox;
        private System.Windows.Forms.TextBox coatsTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label minimumGallonsLabel;
        private System.Windows.Forms.Label gallonsNeededLabel;
        private System.Windows.Forms.Label minimumOutputLabel;
        private System.Windows.Forms.Label neededOutputLabel;
    }
}

